#!/usr/bin/env python3
"""Static validation that does not require .NET or Autodesk assemblies."""

from __future__ import annotations

import sys
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "src" / "AutoGIS.Civil3D.Diagnostics" / "AutoGIS.Civil3D.Diagnostics.csproj"
SOURCE = ROOT / "src" / "AutoGIS.Civil3D.Diagnostics" / "DiagnosticsCommands.cs"
MANIFEST = ROOT / "bundle" / "AutoGIS.Civil3D.Diagnostics.bundle" / "PackageContents.xml"
BUILD_SCRIPT = ROOT / "scripts" / "Build-Diagnostics.ps1"
INSTALL_SCRIPT = ROOT / "scripts" / "Install-CurrentUser.ps1"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    for path in (PROJECT, SOURCE, MANIFEST, BUILD_SCRIPT, INSTALL_SCRIPT):
        require(path.is_file(), f"Missing required file: {path.relative_to(ROOT)}")

    project_text = PROJECT.read_text(encoding="utf-8")
    source_text = SOURCE.read_text(encoding="utf-8")
    build_text = BUILD_SCRIPT.read_text(encoding="utf-8")
    install_text = INSTALL_SCRIPT.read_text(encoding="utf-8")

    require("<TargetFramework>net8.0-windows</TargetFramework>" in project_text, "Project must target net8.0-windows")
    require("<PlatformTarget>x64</PlatformTarget>" in project_text, "Project must target x64")
    require('FrameworkReference Include="Microsoft.WindowsDesktop.App"' in project_text, "Windows Desktop framework reference is missing")
    for assembly in ("AcCoreMgd", "AcDbMgd", "AcMgd", "AecBaseMgd", "AeccDbMgd"):
        require(f'<Reference Include="{assembly}">' in project_text, f"Missing reference: {assembly}")
    require(project_text.count("<Private>false</Private>") == 5, "Autodesk references must not be copied locally")

    require('[CommandMethod("AUTOGISDIAGNOSTICS", CommandFlags.Modal)]' in source_text, "Diagnostic command is not registered")
    require("CivilApplication.ActiveDocument" in source_text, "Civil 3D API is not exercised")
    require("SECURELOAD" in source_text and "TRUSTEDPATHS" in source_text, "Security settings are not reported")
    require("allSectionsSucceeded" in source_text and "PARTIAL" in source_text, "Final result must reflect section failures")
    forbidden = (
        "Process.Start",
        "ProcessStartInfo",
        "File.Write",
        "FileStream",
        "HttpClient",
        "WebRequest",
        "SetSystemVariable",
        "StartTransaction",
        "OpenMode.ForWrite",
    )
    for token in forbidden:
        require(token not in source_text, f"Read-only source contains forbidden token: {token}")

    xml_root = ET.parse(MANIFEST).getroot()
    require(xml_root.tag == "ApplicationPackage", "Unexpected manifest root")
    component = xml_root.find("./Components/ComponentEntry")
    require(component is not None, "ComponentEntry is missing")
    require(component.attrib.get("AppType") == ".Net", "Component must be identified as a .NET plug-in")
    runtime = component.find("./RuntimeRequirements")
    require(runtime is not None, "RuntimeRequirements is missing")
    require(runtime.attrib.get("Platform") == "Civil3D", "Bundle must target Civil3D")
    require(runtime.attrib.get("OS") == "Win64", "Bundle must target Win64")
    require(runtime.attrib.get("SeriesMin") == "R25.0", "SeriesMin must be R25.0")
    require(runtime.attrib.get("SeriesMax") == "R25.0", "SeriesMax must be R25.0")
    require(
        component.attrib.get("ModuleName") == "./Contents/2025/AutoGIS.Civil3D.Diagnostics.dll",
        "Unexpected module path",
    )
    command = component.find("./Commands/Command")
    require(command is not None and command.attrib.get("Global") == "AUTOGISDIAGNOSTICS", "Manifest command mismatch")

    require("dotnet" in build_text, "Build script does not invoke dotnet")
    require("Civil3D_2025_ROOT" in build_text or "CIVIL3D_2025_ROOT" in build_text, "Build script lacks Civil 3D root override")
    require("@(13, 7)" in build_text and "@(25, 0)" in build_text, "Build script must reject cross-version Autodesk assemblies")
    require("$env:APPDATA" in install_text, "Installer must use the current-user APPDATA location")
    require("ProgramFiles" not in install_text, "Current-user installer must not write to Program Files")

    print("Static validation passed: project, read-only command, manifest, build script, and per-user installer.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"VALIDATION FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
