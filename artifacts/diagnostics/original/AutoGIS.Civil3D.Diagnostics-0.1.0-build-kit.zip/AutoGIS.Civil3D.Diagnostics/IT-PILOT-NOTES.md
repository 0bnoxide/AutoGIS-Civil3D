# AutoGIS Civil 3D Diagnostics — IT/CAD Pilot Notes

## Purpose

Validate whether an internally developed, read-only .NET 8 plug-in can load in
Autodesk Civil 3D 2025 before development of the AutoGIS/Civil 3D bridge.

## Command

```text
AUTOGISDIAGNOSTICS
```

## Runtime behavior

- Loads only in 64-bit Civil 3D release series `R25.0` (2025).
- Reads host, drawing, Civil 3D setting, and object-count information.
- Writes output only to the Civil 3D command line.
- Makes no drawing or database changes.
- Does not save the drawing.
- Performs no file, registry, network, HTTP, socket, or subprocess operations.
- Does not start AutoGIS or Python.
- Requires no elevated privileges at runtime.

## Autodesk references

The project compiles against the managed assemblies already installed with
Civil 3D 2025. Autodesk assemblies are marked `Private=false` and are not copied
or redistributed with the plug-in.

## Pilot deployment

The included current-user installer copies the bundle to:

```text
%APPDATA%\Autodesk\ApplicationPlugins\AutoGIS.Civil3D.Diagnostics.bundle
```

For organization-managed deployment, IT may instead place an approved/signed
bundle under:

```text
%PROGRAMFILES%\Autodesk\ApplicationPlugins
```

The source package does not change `SECURELOAD`, `TRUSTEDPATHS`, `APPAUTOLOAD`,
Windows Defender, AppLocker, WDAC, or endpoint-protection policies.

## Removal

The uninstall script moves only the specifically named diagnostic bundle into
a timestamped backup under `%LOCALAPPDATA%\AutoGIS\PluginBackups`.

