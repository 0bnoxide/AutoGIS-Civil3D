[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$repositoryRoot = Split-Path -Parent $PSScriptRoot
$sourceBundle = Join-Path $repositoryRoot "bundle\AutoGIS.Civil3D.Diagnostics.bundle"
$sourceDll = Join-Path $sourceBundle "Contents\2025\AutoGIS.Civil3D.Diagnostics.dll"

if (-not (Test-Path -LiteralPath $sourceDll -PathType Leaf)) {
    throw "The compiled DLL is missing. Run build.cmd before installing."
}

if ([string]::IsNullOrWhiteSpace($env:APPDATA)) {
    throw "APPDATA is not defined for the current Windows user."
}

if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    throw "LOCALAPPDATA is not defined for the current Windows user."
}

$applicationPlugins = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins"
$targetBundle = Join-Path $applicationPlugins "AutoGIS.Civil3D.Diagnostics.bundle"
$backupRoot = Join-Path $env:LOCALAPPDATA "AutoGIS\PluginBackups"

New-Item -ItemType Directory -Path $applicationPlugins -Force | Out-Null

if (Test-Path -LiteralPath $targetBundle) {
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backup = Join-Path $backupRoot "AutoGIS.Civil3D.Diagnostics.bundle-$timestamp"
    Move-Item -LiteralPath $targetBundle -Destination $backup
    Write-Host "Previous bundle moved to: $backup"
}

Copy-Item -LiteralPath $sourceBundle -Destination $applicationPlugins -Recurse -Force

$installedDll = Join-Path $targetBundle "Contents\2025\AutoGIS.Civil3D.Diagnostics.dll"
if (-not (Test-Path -LiteralPath $installedDll -PathType Leaf)) {
    throw "Installation did not produce the expected DLL: $installedDll"
}

$hash = (Get-FileHash -LiteralPath $installedDll -Algorithm SHA256).Hash
Write-Host "Installed current-user bundle: $targetBundle"
Write-Host "DLL SHA256: $hash"
Write-Host "Restart Civil 3D (or reload bundles with APPAUTOLOADER), then run AUTOGISDIAGNOSTICS."
