[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($env:APPDATA)) {
    throw "APPDATA is not defined for the current Windows user."
}

if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    throw "LOCALAPPDATA is not defined for the current Windows user."
}

$targetBundle = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\AutoGIS.Civil3D.Diagnostics.bundle"
if (-not (Test-Path -LiteralPath $targetBundle)) {
    Write-Host "The current-user diagnostic bundle is not installed."
    exit 0
}

$backupRoot = Join-Path $env:LOCALAPPDATA "AutoGIS\PluginBackups"
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $backupRoot "AutoGIS.Civil3D.Diagnostics.bundle-uninstalled-$timestamp"

Move-Item -LiteralPath $targetBundle -Destination $backup
Write-Host "Bundle removed from the Autodesk loader path and preserved at: $backup"
